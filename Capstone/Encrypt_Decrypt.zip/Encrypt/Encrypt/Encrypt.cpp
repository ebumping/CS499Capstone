// Encrypt.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include<fstream>
#include<stdio.h>
using namespace std;

int main()
{
    //declare variables for filename, char c, and fstreams
    char fileName[30], c;
    fstream fs, ft;
    //prompt user for name of file
    cout << "Enter the Name of File with extension: ";
    //attempt to open specified file
    gets_s(fileName, 30);
    fs.open(fileName, fstream::in);
    //Handle errors with input
    if (!fs) {
        cout << "\nError Occurred Opening the Source file to read";
        return 0;
    }
    ft.open("temp.txt", fstream::out);
    //Handle errors with fstream ft
    if (!ft) {
        cout << "\nError Occured Opening/Creating the temp File";
        return 0;
    }
    while (fs >> noskipws >> c) {
        c = c + 100;
        ft << c;
    }
    fs.close();
    ft.close();
    fs.open(fileName, fstream::out);
    if (!fs) {
        cout << "\nError Occurred Opening the Source file to write";
        return 0;
    }
    ft.open("temp.txt", fstream::in);
    if (!ft) {
        cout << "\nError Occured Opening the temp file";
        return 0;
    }
    while (ft >> noskipws >> c) 
        fs << c;
    fs.close();
    ft.close();
    cout << "\nFile '" << fileName << "' Encrypted Successfully." << endl;
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
